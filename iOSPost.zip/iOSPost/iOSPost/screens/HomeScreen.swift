//
//  HomeScreen.swift
//  iOSPost
//
//  Created by Muhammad Islamov on 04/03/22.
//

import SwiftUI

struct HomeScreen: View {
  @EnvironmentObject var session: SessionStore
  @State var isLoading = false
  func signOut(){
    isLoading = true
    if SessionStore().signOut() {
      isLoading = false
      session.listen()
    }
  }
    var body: some View {
      NavigationView {
        ZStack{
          if let email = session.session?.email {
            Text("Welcome " + email)
          }
          if isLoading{
            ProgressView()
          }
        }
        .navigationBarItems(trailing:
                              HStack{
          Button(action: {

          }, label: {
            Image(systemName: "clock")
          })
          Button(action: {
            signOut()
          }, label: {
            Image(systemName: "clock")
          })
        }
        )
        .navigationBarTitle("Posts", displayMode: .inline)
      }
    }
}

struct HomeScreen_Previews: PreviewProvider {
    static var previews: some View {
        HomeScreen()
    }
}
