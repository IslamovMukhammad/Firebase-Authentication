//
//  iOSPostApp.swift
//  iOSPost
//
//  Created by Muhammad Islamov on 04/03/22.
//

import SwiftUI
import Firebase

@main


struct iOSPostApp: App {

  @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
          StarterScreen().environmentObject(SessionStore())
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication, didFinishLaunchingWithOptions lauchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {

    FirebaseApp.configure()

    return true

  }
}
